/* ============================================================
   GO ONBOARD v2.0 — script.js
   Menú móvil · Carrusel · Sidebar acordeón · Scroll reveal
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

  /* ──────────────────────────────────────────────────────────
     1. MENÚ HAMBURGUESA
  ────────────────────────────────────────────────────────── */
  const navToggle = document.getElementById('nav-toggle');
  const mainNav   = document.getElementById('main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('open');
      navToggle.classList.toggle('open', isOpen);
      navToggle.setAttribute('aria-expanded', isOpen);
      navToggle.setAttribute('aria-label', isOpen ? 'Cerrar menú' : 'Abrir menú');
    });

    // Cerrar al navegar
    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mainNav.classList.remove('open');
        navToggle.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
        navToggle.setAttribute('aria-label', 'Abrir menú');
      });
    });

    // Cerrar al hacer click fuera
    document.addEventListener('click', (e) => {
      if (!navToggle.contains(e.target) && !mainNav.contains(e.target)) {
        mainNav.classList.remove('open');
        navToggle.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }


  /* ──────────────────────────────────────────────────────────
     2. CARRUSEL
  ────────────────────────────────────────────────────────── */
  const slides   = document.querySelectorAll('.carousel__slide');
  const dots     = document.querySelectorAll('.carousel__dot');
  const prevBtn  = document.getElementById('prev-btn');
  const nextBtn  = document.getElementById('next-btn');

  if (slides.length > 0) {
    let current   = 0;
    let autoTimer = null;

    function goTo(index) {
      slides[current].classList.remove('active');
      dots[current].classList.remove('active');
      dots[current].setAttribute('aria-selected', 'false');

      current = (index + slides.length) % slides.length;

      slides[current].classList.add('active');
      dots[current].classList.add('active');
      dots[current].setAttribute('aria-selected', 'true');
    }

    function startAuto() {
      clearInterval(autoTimer);
      autoTimer = setInterval(() => goTo(current + 1), 5500);
    }

    if (prevBtn) prevBtn.addEventListener('click', () => { goTo(current - 1); startAuto(); });
    if (nextBtn) nextBtn.addEventListener('click', () => { goTo(current + 1); startAuto(); });

    dots.forEach((dot, i) => {
      dot.addEventListener('click', () => { goTo(i); startAuto(); });
      dot.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); goTo(i); startAuto(); }
      });
    });

    // Pausa en hover
    const carouselCard = document.querySelector('.carousel-card');
    if (carouselCard) {
      carouselCard.addEventListener('mouseenter', () => clearInterval(autoTimer));
      carouselCard.addEventListener('mouseleave', startAuto);
    }

    // Swipe táctil
    let touchStartX = 0;
    const hero = document.querySelector('.hero__visual');
    if (hero) {
      hero.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
      hero.addEventListener('touchend',   e => {
        const dx = e.changedTouches[0].clientX - touchStartX;
        if (Math.abs(dx) > 50) { goTo(dx < 0 ? current + 1 : current - 1); startAuto(); }
      }, { passive: true });
    }

    startAuto();
  }


  /* ──────────────────────────────────────────────────────────
     3. SIDEBAR ACORDEÓN
  ────────────────────────────────────────────────────────── */
  document.querySelectorAll('.sidebar__section-title').forEach(title => {
    title.addEventListener('click', () => {
      const section  = title.closest('.sidebar__section');
      const expanded = title.getAttribute('aria-expanded') === 'true';
      section.classList.toggle('collapsed', expanded);
      title.setAttribute('aria-expanded', !expanded);
    });
  });


  /* ──────────────────────────────────────────────────────────
     4. SCROLL REVEAL (IntersectionObserver)
     Añade clase .visible a elementos .reveal cuando entran en pantalla
  ────────────────────────────────────────────────────────── */
  if ('IntersectionObserver' in window) {
    // Marcar activo en sidebar al scrollear
    const sidebarLinks = document.querySelectorAll('.sidebar__list a');
    const sections = document.querySelectorAll('.content-module[id]');

    if (sidebarLinks.length > 0 && sections.length > 0) {
      const sectionObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const id = entry.target.id;
            sidebarLinks.forEach(link => {
              const href = link.getAttribute('href').replace('#', '');
              link.classList.toggle('active', href === id);
            });
          }
        });
      }, { threshold: 0.4, rootMargin: '-80px 0px 0px 0px' });

      sections.forEach(s => sectionObserver.observe(s));
    }

    // Stat cards — efecto de conteo al entrar en viewport
    const statCards = document.querySelectorAll('.stat-card');
    if (statCards.length > 0) {
      const statObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
            statObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.3 });

      statCards.forEach((card, i) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(16px)';
        card.style.transition = `opacity 0.5s ease ${i * 0.1}s, transform 0.5s ease ${i * 0.1}s`;
        statObserver.observe(card);
      });
    }

    // Step cards
    const stepCards = document.querySelectorAll('.step-card');
    if (stepCards.length > 0) {
      const stepObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
            stepObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.2 });

      stepCards.forEach((card, i) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = `opacity 0.55s ease ${i * 0.15}s, transform 0.55s ease ${i * 0.15}s`;
        stepObserver.observe(card);
      });
    }
  }

});
